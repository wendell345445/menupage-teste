import { useEffect, useId, useMemo, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'

import { useMenu } from '@/hooks/useMenu'
import { useStoreSlug } from '@/hooks/useStoreSlug'
import { resolveImageUrl } from '@/shared/lib/imageUrl'
import type { Product, ProductOption, ProductOptionGroup } from '@/services/menu.service'
import { useCartStore } from '@/store/useCartStore'

type PizzaOptionView = {
  id: string
  name: string
  priceValue: number
  price: string
  description: string
  image: string
}

type BorderOptionView = {
  id: string
  name: string
  priceValue: number
  price: string
  description: string
}

const fallbackPizzaDescription =
  'Molho de tomate, mussarela e ingredientes selecionados. Sabor artesanal para combinar com sua pizza.'

const fallbackBorderDescription = 'Borda recheada preparada com massa artesanal e recheio cremoso.'

const fallbackProduct = {
  id: 'pizza-grande-2-sabores',
  name: 'Pizza (Grande) 8 pedaços',
  description:
    'A pizza portuguesa é um clássico brasileiro criado por padeiros de origem lusa, e não um prato tradicional de Portugal.',
  imageUrl: '/product-page/pizza-portuguesa.png',
}

const fallbackPizzaOptions: PizzaOptionView[] = [
  {
    id: 'a-moda-da-casa',
    name: 'Á Moda da casa',
    priceValue: 49.99,
    price: '+ R$ 49,99',
    description: fallbackPizzaDescription,
    image: '/product-page/adicionais-3.png',
  },
  {
    id: 'frango-catupiry',
    name: 'Frango Catupiry',
    priceValue: 49.99,
    price: '+ R$ 49,99',
    description: fallbackPizzaDescription,
    image: '/product-page/frango-catupiry.png',
  },
  {
    id: 'calabresa',
    name: 'Calabresa',
    priceValue: 49.99,
    price: '+ R$ 49,99',
    description: fallbackPizzaDescription,
    image: '/product-page/adicionais-3.png',
  },
]

const fallbackBorderOptions: BorderOptionView[] = [
  {
    id: 'catupiry-borda',
    name: 'Catupiry',
    priceValue: 9.99,
    price: '+ R$ 9,99',
    description: fallbackBorderDescription,
  },
  {
    id: 'calabresa-borda',
    name: 'Calabresa',
    priceValue: 9.99,
    price: '+ R$ 9,99',
    description: fallbackBorderDescription,
  },
]

function fmtBRL(value: number) {
  return value.toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' })
}

function fmtOptionPrice(value?: number | null) {
  const numericValue = value ?? 0
  return `+ ${fmtBRL(numericValue)}`
}

function resolvePublicImage(url?: string | null) {
  if (!url) return null
  return resolveImageUrl(url) ?? url
}

function getActiveOptions(group?: ProductOptionGroup | null) {
  return group?.options.filter((option) => option.isActive !== false) ?? []
}

function cleanDescription(value?: string | null, fallback = fallbackPizzaDescription) {
  const text = value?.trim() || fallback
  return text.length > 98 ? `${text.slice(0, 95).trim()}...` : text
}

function toPizzaOptionView(option: ProductOption): PizzaOptionView {
  const isFrangoCatupiry = option.id === 'frango-catupiry' || option.name.toLowerCase().includes('frango')

  return {
    id: option.id,
    name: option.name,
    priceValue: option.price ?? 0,
    price: fmtOptionPrice(option.price),
    description: cleanDescription(option.description, fallbackPizzaDescription),
    image:
      resolvePublicImage(option.imageUrl) ||
      (isFrangoCatupiry ? '/product-page/frango-catupiry.png' : '/product-page/adicionais-3.png'),
  }
}

function toBorderOptionView(option: ProductOption): BorderOptionView {
  return {
    id: option.id,
    name: option.name,
    priceValue: option.price ?? 0,
    price: fmtOptionPrice(option.price),
    description: cleanDescription(option.description, fallbackBorderDescription),
  }
}

function getProductById(data: ReturnType<typeof useMenu>['data'], id?: string) {
  if (!data || !id) return null

  return (
    data.categories
      .flatMap((category) => category.products)
      .find((item) => item.id === id) ?? null
  )
}

function getBasePrice(product: Product | null) {
  if (!product) return 0
  if (product.promoPrice != null) return product.promoPrice
  if (product.basePrice != null) return product.basePrice
  return 0
}

function useProductScreenData(product: Product | null) {
  return useMemo(() => {
    const groups = product?.optionGroups ?? []
    const pizzaGroup = groups[0]
    const borderGroup = groups[1]
    const pizzaOptions = getActiveOptions(pizzaGroup).map(toPizzaOptionView)
    const borderOptions = getActiveOptions(borderGroup).map(toBorderOptionView)

    return {
      productId: product?.id || fallbackProduct.id,
      productTitle: product?.name || fallbackProduct.name,
      productDescription: cleanDescription(product?.description, fallbackProduct.description),
      productImage: resolvePublicImage(product?.imageUrl) || fallbackProduct.imageUrl,
      basePrice: getBasePrice(product),
      pizzaGroupTitle: pizzaGroup?.title || 'Pizzas (Grande)',
      pizzaGroupHelper: pizzaGroup?.helperText || 'Escolha até 2 opções',
      pizzaMax: pizzaGroup?.max ?? 2,
      pizzaOptions: pizzaOptions.length > 0 ? pizzaOptions : fallbackPizzaOptions,
      borderGroupTitle: borderGroup?.title || 'Qual sabor da borda?',
      borderGroupHelper: borderGroup?.helperText || 'Escolha 1 opção',
      borderOptions: borderOptions.length > 0 ? borderOptions : fallbackBorderOptions,
    }
  }, [product])
}

function RequiredBadge() {
  return (
    <span className="rounded-[4px] bg-[#2E2F31] px-2 py-[3px] text-[10px] font-normal leading-none text-white">
      Obrigatório
    </span>
  )
}

function CountBadge({ current, total }: { current: number; total: number }) {
  return (
    <span className="rounded-[4px] bg-white px-2 py-[3px] text-[10px] font-bold leading-none text-[#2E2F31] shadow-[inset_0_0_0_1px_rgba(46,47,49,0.16)]">
      {current} de {total}
    </span>
  )
}

function CompletedBadge() {
  return (
    <span className="rounded-[4px] bg-[#14BE39] px-2 py-[3px] text-[10px] font-bold leading-none text-white">
      Concluído
    </span>
  )
}

function SectionHeader({
  title,
  helper,
  selectedCount = 0,
  maxCount,
  completed = false,
}: {
  title: string
  helper: string
  selectedCount?: number
  maxCount?: number
  completed?: boolean
}) {
  return (
    <div className="flex min-h-[58px] items-start justify-between gap-3 bg-[#F3F3F3] px-[13px] py-[12px] sm:px-6">
      <div className="min-w-0">
        <h2 className="text-[12px] font-bold leading-none text-[#2E2F31] sm:text-[13px]">{title}</h2>
        <p className="mt-[9px] text-[8px] font-normal leading-none text-[#2E2F31] sm:text-[9px]">{helper}</p>
      </div>

      <div className="flex shrink-0 items-center gap-1.5">
        {selectedCount > 0 && typeof maxCount === 'number' ? (
          <CountBadge current={selectedCount} total={maxCount} />
        ) : (
          <RequiredBadge />
        )}
        {completed ? <CompletedBadge /> : null}
      </div>
    </div>
  )
}

function PizzaQuantityControl({
  quantity,
  onIncrement,
  onDecrement,
  incrementDisabled,
}: {
  quantity: number
  onIncrement: () => void
  onDecrement: () => void
  incrementDisabled: boolean
}) {
  if (quantity <= 0) {
    return (
      <button
        type="button"
        onClick={onIncrement}
        className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[#2E2F31] active:scale-95"
        aria-label="Adicionar sabor"
      >
        <span
          className="h-3.5 w-3.5 bg-[url('/product-page/vector-2.svg')] bg-contain bg-center bg-no-repeat"
          aria-hidden="true"
        />
      </button>
    )
  }

  return (
    <div className="flex h-7 shrink-0 items-center overflow-hidden rounded-full bg-[#F4F4F4] shadow-[inset_0_0_0_1px_rgba(46,47,49,0.12)]">
      <button
        type="button"
        onClick={onDecrement}
        className="flex h-full w-7 items-center justify-center text-[15px] font-bold leading-none text-[#2E2F31] active:scale-95"
        aria-label="Remover sabor"
      >
        −
      </button>
      <span className="min-w-4 text-center text-[11px] font-bold leading-none text-[#2E2F31]">{quantity}</span>
      <button
        type="button"
        onClick={onIncrement}
        disabled={incrementDisabled}
        className="flex h-full w-7 items-center justify-center text-[15px] font-bold leading-none text-[#2E2F31] active:scale-95 disabled:opacity-35"
        aria-label="Adicionar mais deste sabor"
      >
        +
      </button>
    </div>
  )
}

function RadioMark({ checked }: { checked: boolean }) {
  return (
    <span
      className="flex h-4 w-4 shrink-0 items-center justify-center rounded-full border border-solid border-[#14BE39]"
      aria-hidden="true"
    >
      {checked ? <span className="h-2 w-2 rounded-full bg-[#14BE39]" /> : null}
    </span>
  )
}

function optionImageFallback(optionName: string) {
  return optionName.toLowerCase().includes('frango')
    ? '/product-page/frango-catupiry.png'
    : '/product-page/adicionais-3.png'
}

export function ProductPage() {
  const { id } = useParams()
  const slug = useStoreSlug()
  const navigate = useNavigate()
  const { data } = useMenu(slug)
  const product = getProductById(data, id) ?? getProductById(data, 'pizza-grande-2-sabores')
  const screen = useProductScreenData(product)
  const addItem = useCartStore((state) => state.addItem)

  const [selectedPizzaQuantities, setSelectedPizzaQuantities] = useState<Record<string, number>>({})
  const [selectedBorder, setSelectedBorder] = useState<string>('')
  const [quantity, setQuantity] = useState(1)
  const pizzaGroupName = useId()

  useEffect(() => {
    setSelectedBorder((current) => current || screen.borderOptions[0]?.id || '')
  }, [screen.borderOptions])

  const totalSelectedPizzas = Object.values(selectedPizzaQuantities).reduce((sum, value) => sum + value, 0)
  const selectedPizzaOptions = screen.pizzaOptions
    .map((option) => ({ ...option, quantity: selectedPizzaQuantities[option.id] ?? 0 }))
    .filter((option) => option.quantity > 0)
  const selectedBorderOption = screen.borderOptions.find((option) => option.id === selectedBorder) ?? null
  const pizzaPrice = selectedPizzaOptions.length > 0 ? Math.max(...selectedPizzaOptions.map((option) => option.priceValue)) : 0
  const borderPrice = selectedBorderOption?.priceValue ?? 0
  const totalPrice = (screen.basePrice + pizzaPrice + borderPrice) * quantity
  const canAdd = totalSelectedPizzas > 0 && Boolean(selectedBorder)
  const pizzaSelectionCompleted = totalSelectedPizzas >= screen.pizzaMax

  const incrementPizzaSelection = (optionId: string) => {
    setSelectedPizzaQuantities((current) => {
      const currentTotal = Object.values(current).reduce((sum, value) => sum + value, 0)
      if (currentTotal >= screen.pizzaMax) return current

      return {
        ...current,
        [optionId]: (current[optionId] ?? 0) + 1,
      }
    })
  }

  const decrementPizzaSelection = (optionId: string) => {
    setSelectedPizzaQuantities((current) => {
      const currentQuantity = current[optionId] ?? 0
      if (currentQuantity <= 0) return current

      const next = { ...current }
      if (currentQuantity === 1) {
        delete next[optionId]
        return next
      }

      next[optionId] = currentQuantity - 1
      return next
    })
  }

  const handleBack = () => {
    if (window.history.length > 1) {
      navigate(-1)
      return
    }

    navigate('/')
  }

  const handleAddToCart = () => {
    if (!canAdd) return

    addItem({
      productId: screen.productId,
      productName: screen.productTitle,
      imageUrl: screen.productImage,
      quantity,
      unitPrice: totalPrice / quantity,
      additionals: [
        ...selectedPizzaOptions.map((option) => ({
          id: option.id,
          name: option.quantity > 1 ? `${option.name} x${option.quantity}` : option.name,
          price: option.priceValue,
          groupId: 'sabores-grande',
          groupName: screen.pizzaGroupTitle,
        })),
        ...(selectedBorderOption
          ? [
              {
                id: selectedBorderOption.id,
                name: selectedBorderOption.name,
                price: selectedBorderOption.priceValue,
                groupId: 'borda-recheada',
                groupName: screen.borderGroupTitle,
              },
            ]
          : []),
      ],
    })

    navigate('/carrinho')
  }

  return (
    <main className="min-h-dvh w-full bg-white [font-family:'Lato',Helvetica,Arial,sans-serif] text-[#2E2F31] antialiased">
      <div className="mx-auto flex min-h-dvh w-full max-w-[768px] flex-col bg-white pb-[104px]">
        <section aria-label="Imagem do produto" className="relative aspect-[390/327] w-full overflow-hidden bg-[#F3F3F3]">
          <img className="h-full w-full object-cover" alt={screen.productTitle} src={screen.productImage} />

          <button
            type="button"
            aria-label="Voltar"
            onClick={handleBack}
            className="absolute left-[13px] top-[26px] flex h-[33px] w-9 items-center justify-center rounded-[7px] bg-[#F2F2F2]/75 active:scale-95"
          >
            <img className="h-[17px] w-[17px] rotate-90" alt="" aria-hidden="true" src="/product-page/vector-3.svg" />
          </button>

          <button
            type="button"
            aria-label="Expandir imagem"
            className="absolute bottom-[7px] right-3 flex h-[30px] w-[30px] items-center justify-center rounded-[7px] bg-[#F2F2F2]/75 active:scale-95"
          >
            <span
              className="h-3.5 w-3.5 bg-[url('/product-page/vector-4.svg')] bg-contain bg-center bg-no-repeat"
              aria-hidden="true"
            />
          </button>
        </section>

        <div className="h-[3px] w-full bg-[#FF8800]" />

        <section aria-labelledby="pizza-title" className="px-[13px] pb-[24px] pt-[13px] sm:px-6 sm:pt-5">
          <h1 id="pizza-title" className="text-[18px] font-bold leading-none text-[#2E2F31] sm:text-[21px]">
            {screen.productTitle}
          </h1>
          <p className="mt-[12px] max-w-[620px] text-[10px] font-normal leading-[1.35] text-[#2E2F31] sm:text-[11px]">
            {screen.productDescription}
          </p>
        </section>

        <section aria-labelledby="sabores-heading" className="w-full">
          <SectionHeader
            title={screen.pizzaGroupTitle}
            helper={screen.pizzaGroupHelper}
            selectedCount={totalSelectedPizzas}
            maxCount={screen.pizzaMax}
            completed={pizzaSelectionCompleted}
          />

          <fieldset className="m-0 border-0 p-0" aria-describedby="sabores-help">
            <legend id="sabores-heading" className="sr-only">
              Selecione até 2 sabores de pizza
            </legend>
            <span id="sabores-help" className="sr-only">
              Você pode selecionar até {screen.pizzaMax} opções.
            </span>

            {screen.pizzaOptions.map((option) => {
              const optionQuantity = selectedPizzaQuantities[option.id] ?? 0
              const checked = optionQuantity > 0
              const incrementDisabled = totalSelectedPizzas >= screen.pizzaMax

              return (
                <div
                  key={option.id}
                  className="grid min-h-[62px] grid-cols-[36px_minmax(0,1fr)_auto] items-start gap-4 border-b border-[#D9D9D9] px-[13px] py-[9px] sm:grid-cols-[44px_minmax(0,1fr)_auto] sm:px-6 sm:py-3"
                >
                  <input
                    type="checkbox"
                    name={pizzaGroupName}
                    checked={checked}
                    onChange={() => (checked ? decrementPizzaSelection(option.id) : incrementPizzaSelection(option.id))}
                    className="sr-only"
                    aria-label={`${option.name} ${option.price}`}
                  />

                  <img
                    className="mt-0.5 h-9 w-9 rounded-[6px] object-cover sm:h-11 sm:w-11"
                    alt=""
                    aria-hidden="true"
                    src={option.image}
                    onError={(event) => {
                      event.currentTarget.onerror = null
                      event.currentTarget.src = optionImageFallback(option.name)
                    }}
                  />

                  <button
                    type="button"
                    onClick={() => {
                      if (checked) return
                      incrementPizzaSelection(option.id)
                    }}
                    className="min-w-0 pr-1 text-left"
                  >
                    <div className="flex min-w-0 items-baseline gap-2">
                      <span className="truncate text-[12px] font-normal leading-none text-[#2E2F31] sm:text-[13px]">
                        {option.name}
                      </span>
                      <span className="shrink-0 text-[8px] font-bold leading-none text-[#2E2F31] sm:text-[9px]">
                        {option.price}
                      </span>
                    </div>
                    <p className="mt-[6px] line-clamp-2 max-w-[430px] text-[7.5px] font-normal leading-[1.22] text-[#2E2F31] sm:text-[9px] sm:leading-[1.32]">
                      {option.description}
                    </p>
                  </button>

                  <PizzaQuantityControl
                    quantity={optionQuantity}
                    onIncrement={() => incrementPizzaSelection(option.id)}
                    onDecrement={() => decrementPizzaSelection(option.id)}
                    incrementDisabled={incrementDisabled}
                  />
                </div>
              )
            })}
          </fieldset>
        </section>

        <section aria-labelledby="borda-heading" className="mt-[18px] w-full">
          <SectionHeader
            title={screen.borderGroupTitle}
            helper={screen.borderGroupHelper}
            selectedCount={selectedBorder ? 1 : 0}
            maxCount={1}
            completed={Boolean(selectedBorder)}
          />

          <fieldset className="m-0 border-0 p-0">
            <legend id="borda-heading" className="sr-only">
              Selecione o sabor da borda
            </legend>

            {screen.borderOptions.slice(0, 3).map((option) => {
              const checked = selectedBorder === option.id

              return (
                <label
                  key={option.id}
                  className="grid min-h-[49px] cursor-pointer grid-cols-[minmax(0,1fr)_auto] items-start gap-4 border-b border-[#D9D9D9] px-[13px] py-[9px] sm:px-6 sm:py-3"
                >
                  <input
                    type="radio"
                    name="border-option"
                    checked={checked}
                    onChange={() => setSelectedBorder(option.id)}
                    className="sr-only"
                    aria-label={`${option.name} ${option.price}`}
                  />

                  <div className="min-w-0">
                    <div className="flex min-w-0 items-baseline gap-2">
                      <span className="truncate text-[12px] font-normal leading-none text-[#2E2F31] sm:text-[13px]">
                        {option.name}
                      </span>
                      <span className="shrink-0 text-[8px] font-bold leading-none text-[#2E2F31] sm:text-[9px]">
                        {option.price}
                      </span>
                    </div>
                    <p className="mt-[6px] line-clamp-2 max-w-[430px] text-[7.5px] font-normal leading-[1.22] text-[#2E2F31] sm:text-[9px] sm:leading-[1.32]">
                      {option.description}
                    </p>
                  </div>

                  <RadioMark checked={checked} />
                </label>
              )
            })}
          </fieldset>
        </section>
      </div>

      <div className="fixed inset-x-0 bottom-0 z-50 mx-auto w-full max-w-[768px] border-t border-[#E8E8E8] bg-white/96 px-[13px] py-3 shadow-[0_-8px_22px_rgba(0,0,0,0.08)] backdrop-blur-xl sm:px-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 shrink-0 items-center overflow-hidden rounded-[7px] border border-[#D9D9D9] bg-white">
            <button
              type="button"
              aria-label="Diminuir quantidade"
              onClick={() => setQuantity((current) => Math.max(1, current - 1))}
              className="flex h-full w-9 items-center justify-center text-[18px] font-bold text-[#2E2F31]"
            >
              −
            </button>
            <span className="min-w-7 text-center text-[12px] font-bold text-[#2E2F31]">{quantity}</span>
            <button
              type="button"
              aria-label="Aumentar quantidade"
              onClick={() => setQuantity((current) => current + 1)}
              className="flex h-full w-9 items-center justify-center text-[18px] font-bold text-[#2E2F31]"
            >
              +
            </button>
          </div>

          <button
            type="button"
            disabled={!canAdd}
            onClick={handleAddToCart}
            className="flex h-10 min-w-0 flex-1 items-center justify-center rounded-[7px] bg-[#FF8800] px-4 text-[12px] font-bold text-white disabled:cursor-not-allowed disabled:bg-[#D9D9D9] disabled:text-[#5B5858] sm:text-[13px]"
          >
            Adicionar · {fmtBRL(totalPrice)}
          </button>
        </div>
      </div>
    </main>
  )
}
